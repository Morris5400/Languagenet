
export const languages = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
  { code: 'hu', name: 'Magyar', flag: '🇭🇺' }
] as const

export const languagePairs = [
  { code: 'hu-de', name: 'Hungarian ↔ German', from: 'hu', to: 'de' },
  { code: 'hu-en', name: 'Hungarian ↔ English', from: 'hu', to: 'en' },
  { code: 'de-en', name: 'German ↔ English', from: 'de', to: 'en' }
] as const

export type Language = typeof languages[number]['code']
export type LanguagePair = typeof languagePairs[number]['code']

export const defaultLanguage: Language = 'en'
export const defaultLanguagePair: LanguagePair = 'de-en'

// Translation keys
export const translations = {
  en: {
    common: {
      loading: 'Loading...',
      error: 'Error',
      save: 'Save',
      cancel: 'Cancel',
      continue: 'Continue',
      back: 'Back',
      next: 'Next',
      finish: 'Finish',
      settings: 'Settings',
      profile: 'Profile',
      logout: 'Logout',
      login: 'Login',
      signup: 'Sign Up',
      beta: 'Beta',
      free: 'Free'
    },
    nav: {
      home: 'Home',
      learn: 'Learn',
      review: 'Review',
      chat: 'Chat Tutor',
      help: 'Help',
      contact: 'Contact'
    },
    auth: {
      signIn: 'Sign In',
      signUp: 'Sign Up',
      email: 'Email',
      password: 'Password',
      username: 'Username',
      firstName: 'First Name',
      lastName: 'Last Name',
      confirmPassword: 'Confirm Password',
      forgotPassword: 'Forgot Password?',
      noAccount: "Don't have an account?",
      hasAccount: 'Already have an account?',
      signingIn: 'Signing in...',
      signingUp: 'Creating account...',
      signInWithGoogle: 'Continue with Google',
      orContinueWith: 'Or continue with',
      acceptTerms: 'I accept the Terms of Service and Privacy Policy'
    },
    home: {
      welcome: 'Welcome to LanguageLearner',
      subtitle: 'Master Hungarian, German, and English with AI-powered lessons',
      startLearning: 'Start Learning',
      tryAsGuest: 'Try as Guest',
      chooseLanguagePair: 'Choose your language pair',
      yourProgress: 'Your Progress',
      continueLesson: 'Continue Lesson',
      reviewCards: 'Review Cards',
      chatWithTutor: 'Chat with AI Tutor'
    },
    lessons: {
      vocabSprint: 'Vocabulary Sprint',
      structureDrill: 'Structure Drill', 
      videoImmersion: 'Video Immersion',
      dialogRoleplay: 'Dialog & Roleplay',
      completed: 'Completed',
      locked: 'Locked',
      hearts: 'Hearts',
      xp: 'XP',
      streak: 'Streak'
    },
    help: {
      searchPlaceholder: 'Search help articles...',
      categories: 'Categories',
      heartSystem: 'How does the heart system work?',
      dailyGoal: 'How to set/change daily goal?',
      offlineLessons: 'How to use offline lessons?',
      srsSystem: 'What is SRS and why is it helpful?',
      dataManagement: 'How to delete/export my data?',
      reportBugs: 'How to report bugs or content issues?'
    },
    contact: {
      title: 'Contact Us',
      name: 'Name',
      subject: 'Subject',
      message: 'Message',
      send: 'Send Message',
      success: 'Message sent successfully!'
    }
  },
  de: {
    common: {
      loading: 'Wird geladen...',
      error: 'Fehler',
      save: 'Speichern',
      cancel: 'Abbrechen',
      continue: 'Weiter',
      back: 'Zurück',
      next: 'Weiter',
      finish: 'Beenden',
      settings: 'Einstellungen',
      profile: 'Profil',
      logout: 'Abmelden',
      login: 'Anmelden',
      signup: 'Registrieren',
      beta: 'Beta',
      free: 'Kostenlos'
    },
    nav: {
      home: 'Startseite',
      learn: 'Lernen',
      review: 'Wiederholen',
      chat: 'Chat Tutor',
      help: 'Hilfe',
      contact: 'Kontakt'
    },
    auth: {
      signIn: 'Anmelden',
      signUp: 'Registrieren',
      email: 'E-Mail',
      password: 'Passwort',
      username: 'Benutzername',
      firstName: 'Vorname',
      lastName: 'Nachname',
      confirmPassword: 'Passwort bestätigen',
      forgotPassword: 'Passwort vergessen?',
      noAccount: 'Noch kein Konto?',
      hasAccount: 'Bereits ein Konto?',
      signingIn: 'Wird angemeldet...',
      signingUp: 'Konto wird erstellt...',
      signInWithGoogle: 'Mit Google fortfahren',
      orContinueWith: 'Oder fortfahren mit',
      acceptTerms: 'Ich akzeptiere die Nutzungsbedingungen und Datenschutzerklärung'
    },
    home: {
      welcome: 'Willkommen bei LanguageLearner',
      subtitle: 'Meistere Ungarisch, Deutsch und Englisch mit KI-gestützten Lektionen',
      startLearning: 'Lernen beginnen',
      tryAsGuest: 'Als Gast testen',
      chooseLanguagePair: 'Wähle dein Sprachpaar',
      yourProgress: 'Dein Fortschritt',
      continueLesson: 'Lektion fortsetzen',
      reviewCards: 'Karten wiederholen',
      chatWithTutor: 'Chat mit KI-Tutor'
    },
    lessons: {
      vocabSprint: 'Vokabel-Sprint',
      structureDrill: 'Struktur-Drill',
      videoImmersion: 'Video-Immersion',
      dialogRoleplay: 'Dialog & Rollenspiel',
      completed: 'Abgeschlossen',
      locked: 'Gesperrt',
      hearts: 'Herzen',
      xp: 'XP',
      streak: 'Serie'
    },
    help: {
      searchPlaceholder: 'Hilfe-Artikel durchsuchen...',
      categories: 'Kategorien',
      heartSystem: 'Wie funktioniert das Herz-System?',
      dailyGoal: 'Wie setze/ändere ich mein Tagesziel?',
      offlineLessons: 'Wie nutze ich Offline-Lektionen?',
      srsSystem: 'Was ist SRS und warum ist es hilfreich?',
      dataManagement: 'Wie lösche/exportiere ich meine Daten?',
      reportBugs: 'Wie melde ich Fehler oder Inhaltsprobleme?'
    },
    contact: {
      title: 'Kontakt',
      name: 'Name',
      subject: 'Betreff',
      message: 'Nachricht',
      send: 'Nachricht senden',
      success: 'Nachricht erfolgreich gesendet!'
    }
  },
  hu: {
    common: {
      loading: 'Betöltés...',
      error: 'Hiba',
      save: 'Mentés',
      cancel: 'Mégse',
      continue: 'Folytatás',
      back: 'Vissza',
      next: 'Következő',
      finish: 'Befejezés',
      settings: 'Beállítások',
      profile: 'Profil',
      logout: 'Kijelentkezés',
      login: 'Bejelentkezés',
      signup: 'Regisztráció',
      beta: 'Beta',
      free: 'Ingyenes'
    },
    nav: {
      home: 'Főoldal',
      learn: 'Tanulás',
      review: 'Ismétlés',
      chat: 'Chat Oktató',
      help: 'Súgó',
      contact: 'Kapcsolat'
    },
    auth: {
      signIn: 'Bejelentkezés',
      signUp: 'Regisztráció',
      email: 'E-mail',
      password: 'Jelszó',
      username: 'Felhasználónév',
      firstName: 'Keresztnév',
      lastName: 'Vezetéknév',
      confirmPassword: 'Jelszó megerősítése',
      forgotPassword: 'Elfelejtett jelszó?',
      noAccount: 'Nincs még fiókja?',
      hasAccount: 'Már van fiókja?',
      signingIn: 'Bejelentkezés...',
      signingUp: 'Fiók létrehozása...',
      signInWithGoogle: 'Folytatás Google-lel',
      orContinueWith: 'Vagy folytatás ezzel',
      acceptTerms: 'Elfogadom a Szolgáltatási Feltételeket és az Adatvédelmi Nyilatkozatot'
    },
    home: {
      welcome: 'Üdvözöljük a LanguageLearner-ben',
      subtitle: 'Sajátítsa el a magyart, németet és angolt AI-alapú leckékkel',
      startLearning: 'Tanulás kezdése',
      tryAsGuest: 'Kipróbálás vendégként',
      chooseLanguagePair: 'Válassza ki a nyelvpárját',
      yourProgress: 'Az Ön haladása',
      continueLesson: 'Lecke folytatása',
      reviewCards: 'Kártyák ismétlése',
      chatWithTutor: 'Chat AI Oktatóval'
    },
    lessons: {
      vocabSprint: 'Szókincs Sprint',
      structureDrill: 'Szerkezet Gyakorlat',
      videoImmersion: 'Video Immerzió',
      dialogRoleplay: 'Párbeszéd és Szerepjáték',
      completed: 'Befejezve',
      locked: 'Zárolt',
      hearts: 'Szívek',
      xp: 'XP',
      streak: 'Sorozat'
    },
    help: {
      searchPlaceholder: 'Segítség cikkek keresése...',
      categories: 'Kategóriák',
      heartSystem: 'Hogyan működik a szív rendszer?',
      dailyGoal: 'Hogyan állítsam be/változtassam meg a napi célt?',
      offlineLessons: 'Hogyan használjam az offline leckéket?',
      srsSystem: 'Mi az SRS és miért hasznos?',
      dataManagement: 'Hogyan töröljem/exportáljam az adataimat?',
      reportBugs: 'Hogyan jelentsek hibákat vagy tartalmi problémákat?'
    },
    contact: {
      title: 'Kapcsolat',
      name: 'Név',
      subject: 'Tárgy',
      message: 'Üzenet',
      send: 'Üzenet küldése',
      success: 'Üzenet sikeresen elküldve!'
    }
  }
}

export type TranslationKey = keyof typeof translations['en']
export type NestedTranslationKey = keyof typeof translations['en']['common']

export function getTranslation(
  lang: Language,
  key: string
): string {
  const keys = key.split('.')
  let value: any = translations[lang] || translations.en
  
  for (const k of keys) {
    value = value?.[k]
    if (!value) break
  }
  
  return value || key
}

export function t(key: string, lang: Language = 'en'): string {
  return getTranslation(lang, key)
}
