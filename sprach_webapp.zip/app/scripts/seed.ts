
import { PrismaClient, CEFRLevel, LessonType, ItemType, ContentSource } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Starting seed...')

  // Create admin user
  const adminPassword = await bcrypt.hash('admin123', 10)
  const adminUser = await prisma.user.upsert({
    where: { email: 'morrispoyotte@gmail.com' },
    update: {},
    create: {
      email: 'morrispoyotte@gmail.com',
      username: 'admin',
      name: 'Admin User',
      password: adminPassword,
      role: 'ADMIN',
      forcePasswordReset: true,
      profile: {
        create: {
          uiLanguage: 'en',
          targetLanguages: ['de', 'hu'],
          languagePair: 'en-de',
          dailyGoalMinutes: 15,
        }
      }
    }
  })
  console.log('✅ Admin user created')

  // Create test user
  const testPassword = await bcrypt.hash('johndoe123', 10)
  const testUser = await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: {},
    create: {
      email: 'john@doe.com',
      username: 'testuser',
      name: 'John Doe',
      firstName: 'John',
      lastName: 'Doe',
      password: testPassword,
      role: 'USER',
      profile: {
        create: {
          uiLanguage: 'en',
          targetLanguages: ['de'],
          languagePair: 'en-de',
          dailyGoalMinutes: 10,
          streak: 7,
          totalXp: 1250,
          hearts: 5,
        }
      }
    }
  })
  console.log('✅ Test user created')

  // Create clusters
  const clusters = [
    {
      slug: 'daily-life',
      titleI18n: {
        en: 'Daily Life & Basics',
        de: 'Alltag & Grundlagen',
        hu: 'Mindennapi élet és alapok'
      },
      descriptionI18n: {
        en: 'Essential vocabulary and phrases for everyday situations',
        de: 'Wichtige Vokabeln und Phrasen für alltägliche Situationen',
        hu: 'Alapvető szókincs és kifejezések mindennapi helyzetekhez'
      },
      icon: '🏠',
      sortOrder: 1
    },
    {
      slug: 'travel-transport',
      titleI18n: {
        en: 'Travel & Transportation',
        de: 'Reise & Transport',
        hu: 'Utazás és közlekedés'
      },
      descriptionI18n: {
        en: 'Navigate and communicate while traveling',
        de: 'Orientierung und Kommunikation auf Reisen',
        hu: 'Tájékozódás és kommunikáció utazás közben'
      },
      icon: '✈️',
      sortOrder: 2
    },
    {
      slug: 'business-work',
      titleI18n: {
        en: 'Business & Work',
        de: 'Geschäft & Arbeit',
        hu: 'Üzleti élet és munka'
      },
      descriptionI18n: {
        en: 'Professional communication and workplace vocabulary',
        de: 'Professionelle Kommunikation und Arbeitsplatz-Vokabular',
        hu: 'Szakmai kommunikáció és munkahelyi szókincs'
      },
      icon: '💼',
      sortOrder: 3
    }
  ]

  const createdClusters = []
  for (const cluster of clusters) {
    const created = await prisma.cluster.upsert({
      where: { slug: cluster.slug },
      update: {},
      create: cluster
    })
    createdClusters.push(created)
  }
  console.log('✅ Clusters created')

  // Create units for each cluster
  const units = [
    // Daily Life units
    {
      clusterId: createdClusters[0].id,
      slug: 'greetings-introductions',
      titleI18n: {
        en: 'Greetings & Introductions',
        de: 'Begrüßungen & Vorstellungen',
        hu: 'Köszöntés és bemutatkozás'
      },
      level: CEFRLevel.A1,
      sortOrder: 1,
      estimatedMinutes: 15
    },
    {
      clusterId: createdClusters[0].id,
      slug: 'family-friends',
      titleI18n: {
        en: 'Family & Friends',
        de: 'Familie & Freunde',
        hu: 'Család és barátok'
      },
      level: CEFRLevel.A1,
      sortOrder: 2,
      estimatedMinutes: 20
    },
    {
      clusterId: createdClusters[0].id,
      slug: 'home-living',
      titleI18n: {
        en: 'Home & Living',
        de: 'Zuhause & Wohnen',
        hu: 'Otthon és lakás'
      },
      level: CEFRLevel.A1,
      sortOrder: 3,
      estimatedMinutes: 18
    },
    // Travel units
    {
      clusterId: createdClusters[1].id,
      slug: 'at-airport',
      titleI18n: {
        en: 'At the Airport',
        de: 'Am Flughafen',
        hu: 'A repülőtéren'
      },
      level: CEFRLevel.A2,
      sortOrder: 1,
      estimatedMinutes: 22
    },
    {
      clusterId: createdClusters[1].id,
      slug: 'hotels-accommodation',
      titleI18n: {
        en: 'Hotels & Accommodation',
        de: 'Hotels & Unterkunft',
        hu: 'Szálloda és szállás'
      },
      level: CEFRLevel.A2,
      sortOrder: 2,
      estimatedMinutes: 25
    },
    {
      clusterId: createdClusters[1].id,
      slug: 'public-transport',
      titleI18n: {
        en: 'Public Transportation',
        de: 'Öffentliche Verkehrsmittel',
        hu: 'Tömegközlekedés'
      },
      level: CEFRLevel.A2,
      sortOrder: 3,
      estimatedMinutes: 20
    },
    // Business units
    {
      clusterId: createdClusters[2].id,
      slug: 'job-interviews',
      titleI18n: {
        en: 'Job Interviews',
        de: 'Vorstellungsgespräche',
        hu: 'Állásinterjúk'
      },
      level: CEFRLevel.B1,
      sortOrder: 1,
      estimatedMinutes: 30
    },
    {
      clusterId: createdClusters[2].id,
      slug: 'office-communication',
      titleI18n: {
        en: 'Office Communication',
        de: 'Bürokommunikation',
        hu: 'Irodai kommunikáció'
      },
      level: CEFRLevel.B1,
      sortOrder: 2,
      estimatedMinutes: 25
    },
    {
      clusterId: createdClusters[2].id,
      slug: 'business-presentations',
      titleI18n: {
        en: 'Business Presentations',
        de: 'Geschäftspräsentationen',
        hu: 'Üzleti prezentációk'
      },
      level: CEFRLevel.B1,
      sortOrder: 3,
      estimatedMinutes: 35
    }
  ]

  const createdUnits = []
  for (const unit of units) {
    const created = await prisma.unit.upsert({
      where: { slug: unit.slug },
      update: {},
      create: unit
    })
    createdUnits.push(created)
  }
  console.log('✅ Units created')

  // Create lessons for the first few units
  const lessons = [
    // Greetings unit lessons
    {
      unitId: createdUnits[0].id,
      slug: 'basic-greetings-vocab',
      type: LessonType.VOCAB_SPRINT,
      titleI18n: {
        en: 'Basic Greetings Vocabulary',
        de: 'Grundbegrüßungen Vokabular',
        hu: 'Alapvető köszöntés szókincs'
      },
      sortOrder: 1,
      durationSeconds: 300,
      xpReward: 10
    },
    {
      unitId: createdUnits[0].id,
      slug: 'greeting-structures',
      type: LessonType.STRUCTURE_DRILL,
      titleI18n: {
        en: 'Greeting Structures',
        de: 'Begrüßungsstrukturen',
        hu: 'Köszöntési struktúrák'
      },
      sortOrder: 2,
      durationSeconds: 400,
      xpReward: 15
    },
    {
      unitId: createdUnits[0].id,
      slug: 'greeting-roleplay',
      type: LessonType.DIALOG_ROLEPLAY,
      titleI18n: {
        en: 'Greeting Conversations',
        de: 'Begrüßungsgespräche',
        hu: 'Köszöntő beszélgetések'
      },
      sortOrder: 3,
      durationSeconds: 500,
      xpReward: 20
    },
    // Family unit lessons
    {
      unitId: createdUnits[1].id,
      slug: 'family-vocab',
      type: LessonType.VOCAB_SPRINT,
      titleI18n: {
        en: 'Family Vocabulary',
        de: 'Familie Vokabular',
        hu: 'Családi szókincs'
      },
      sortOrder: 1,
      durationSeconds: 400,
      xpReward: 12
    }
  ]

  const createdLessons = []
  for (const lesson of lessons) {
    const created = await prisma.lesson.upsert({
      where: { slug: lesson.slug },
      update: {},
      create: lesson
    })
    createdLessons.push(created)
  }
  console.log('✅ Lessons created')

  // Create some sample items for the first lesson
  const items = [
    {
      lessonId: createdLessons[0].id,
      type: ItemType.VOCABULARY_CARD,
      payload: {
        question: {
          en: 'How do you say "Hello" in German?',
          de: 'Wie sagt man "Hallo" auf Deutsch?'
        },
        answer: {
          text: 'Hallo',
          pronunciation: 'HAH-loh',
          audio: null
        },
        explanation: {
          en: '"Hallo" is the most common informal greeting in German, used throughout the day.',
          de: '"Hallo" ist die häufigste informelle Begrüßung im Deutschen, die den ganzen Tag verwendet wird.'
        }
      },
      languagePair: 'en-de',
      source: ContentSource.FIXED
    },
    {
      lessonId: createdLessons[0].id,
      type: ItemType.VOCABULARY_CARD,
      payload: {
        question: {
          en: 'How do you say "Good morning" in German?',
          de: 'Wie sagt man "Guten Morgen" auf Deutsch?'
        },
        answer: {
          text: 'Guten Morgen',
          pronunciation: 'GOO-ten MOR-gen',
          audio: null
        },
        explanation: {
          en: '"Guten Morgen" is used until about 10 AM. It\'s more formal than "Hallo".',
          de: '"Guten Morgen" wird bis etwa 10 Uhr verwendet. Es ist formeller als "Hallo".'
        }
      },
      languagePair: 'en-de',
      source: ContentSource.FIXED
    }
  ]

  for (const item of items) {
    // Check if item already exists
    const existingItem = await prisma.item.findFirst({
      where: {
        lessonId: item.lessonId,
        type: item.type as any
      }
    })

    if (!existingItem) {
      await prisma.item.create({
        data: item
      })
    }
  }
  console.log('✅ Items created')

  // Create FAQ entries
  const faqEntries = [
    {
      category: 'hearts',
      questionI18n: {
        en: 'How does the heart system work?',
        de: 'Wie funktioniert das Herz-System?',
        hu: 'Hogyan működik a szív rendszer?'
      },
      answerI18n: {
        en: 'You start with 5 hearts each day. When you make a mistake in a lesson, you lose one heart. Hearts refill every 4 hours, or you can practice old lessons to earn them back faster.',
        de: 'Sie beginnen jeden Tag mit 5 Herzen. Wenn Sie einen Fehler in einer Lektion machen, verlieren Sie ein Herz. Herzen füllen sich alle 4 Stunden wieder auf, oder Sie können alte Lektionen üben, um sie schneller zurückzugewinnen.',
        hu: 'Minden nap 5 szívvel kezd. Amikor hibát követ el egy leckében, elveszít egy szívet. A szívek 4 óránként újratöltődnek, vagy régi leckéket gyakorolva gyorsabban visszanyerheti őket.'
      },
      searchKeywords: ['hearts', 'lives', 'mistakes', 'herzen', 'szívek'],
      sortOrder: 1
    },
    {
      category: 'goals',
      questionI18n: {
        en: 'How to set or change my daily goal?',
        de: 'Wie setze oder ändere ich mein Tagesziel?',
        hu: 'Hogyan állítsam be vagy változtassam meg a napi célomat?'
      },
      answerI18n: {
        en: 'Go to your Profile settings and adjust your daily goal. You can choose between 5, 10, 15, 20, or 30 minutes per day. Start small and build consistency!',
        de: 'Gehen Sie zu Ihren Profileinstellungen und passen Sie Ihr Tagesziel an. Sie können zwischen 5, 10, 15, 20 oder 30 Minuten pro Tag wählen. Beginnen Sie klein und bauen Sie Beständigkeit auf!',
        hu: 'Menjen a Profil beállításokhoz, és állítsa be a napi célt. 5, 10, 15, 20 vagy 30 perc között választhat naponta. Kezdje kicsiben és építse fel a következetességet!'
      },
      searchKeywords: ['goal', 'daily', 'minutes', 'ziel', 'cél', 'napi'],
      sortOrder: 2
    }
  ]

  for (const faq of faqEntries) {
    // Check if FAQ already exists
    const existingFAQ = await prisma.fAQ.findFirst({
      where: {
        category: faq.category
      }
    })

    if (!existingFAQ) {
      await prisma.fAQ.create({
        data: faq
      })
    }
  }
  console.log('✅ FAQ entries created')

  // Create some badges
  const badges = [
    {
      slug: 'first-lesson',
      nameI18n: {
        en: 'First Steps',
        de: 'Erste Schritte',
        hu: 'Első lépések'
      },
      descriptionI18n: {
        en: 'Complete your first lesson',
        de: 'Schließe deine erste Lektion ab',
        hu: 'Teljesítsd az első leckédet'
      },
      icon: '👶',
      condition: { type: 'lessons_completed', value: 1 },
      rarity: 'common',
      xpBonus: 10
    },
    {
      slug: 'week-warrior',
      nameI18n: {
        en: 'Week Warrior',
        de: 'Wochen-Krieger',
        hu: 'Heti harcos'
      },
      descriptionI18n: {
        en: 'Maintain a 7-day streak',
        de: 'Halte eine 7-Tage-Serie aufrecht',
        hu: 'Tartsd fenn a 7 napos sorozatot'
      },
      icon: '🔥',
      condition: { type: 'streak', value: 7 },
      rarity: 'rare',
      xpBonus: 50
    }
  ]

  for (const badge of badges) {
    await prisma.badge.upsert({
      where: { slug: badge.slug },
      update: {},
      create: badge
    })
  }
  console.log('✅ Badges created')

  console.log('🎉 Seed completed successfully!')
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
