
'use client'

import { useState, useEffect } from 'react'
import { toast } from 'sonner'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { useLanguage } from '@/components/providers/language-provider'
import { 
  ArrowLeft,
  Play,
  Clock,
  Target,
  Brain,
  Video,
  MessageSquare,
  CheckCircle,
  Lock,
  Star
} from 'lucide-react'

interface Props {
  unitId: string
}

// Mock data - would come from database
const unitData = {
  '1': {
    title: 'Greetings & Introductions',
    description: 'Learn essential greetings and how to introduce yourself',
    level: 'A1',
    cluster: 'Daily Life & Basics',
    estimatedMinutes: 15,
    progress: 100,
    lessons: [
      {
        id: '1',
        title: 'Basic Greetings Vocabulary',
        type: 'VOCAB_SPRINT',
        completed: true,
        duration: 5,
        xp: 10
      },
      {
        id: '2',
        title: 'Greeting Structures',
        type: 'STRUCTURE_DRILL',
        completed: true,
        duration: 6,
        xp: 15
      },
      {
        id: '3',
        title: 'Greeting Conversations',
        type: 'DIALOG_ROLEPLAY',
        completed: true,
        duration: 8,
        xp: 20
      }
    ]
  },
  '2': {
    title: 'Family & Friends',
    description: 'Talk about your family and friends',
    level: 'A1',
    cluster: 'Daily Life & Basics',
    estimatedMinutes: 20,
    progress: 67,
    lessons: [
      {
        id: '4',
        title: 'Family Vocabulary',
        type: 'VOCAB_SPRINT',
        completed: true,
        duration: 5,
        xp: 12
      },
      {
        id: '5',
        title: 'Describing People',
        type: 'STRUCTURE_DRILL',
        completed: true,
        duration: 7,
        xp: 15
      },
      {
        id: '6',
        title: 'Family Conversations',
        type: 'DIALOG_ROLEPLAY',
        completed: false,
        duration: 8,
        xp: 20
      }
    ]
  }
}

const lessonIcons = {
  'VOCAB_SPRINT': Brain,
  'STRUCTURE_DRILL': Target,
  'VIDEO_IMMERSION': Video,
  'DIALOG_ROLEPLAY': MessageSquare
}

const lessonColors = {
  'VOCAB_SPRINT': 'bg-blue-500',
  'STRUCTURE_DRILL': 'bg-green-500',
  'VIDEO_IMMERSION': 'bg-purple-500',
  'DIALOG_ROLEPLAY': 'bg-orange-500'
}

export default function UnitPage({ unitId }: Props) {
  const { language } = useLanguage()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <div className="flex items-center justify-center min-h-[50vh]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
    </div>
  }

  const unit = unitData[unitId as keyof typeof unitData] || unitData['1']

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Link 
          href="/learn" 
          className="flex items-center text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Learn
        </Link>
        <Badge variant="outline">{unit.level}</Badge>
      </div>

      {/* Unit Info */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center space-x-2 mb-2">
                <CardTitle className="text-2xl">{unit.title}</CardTitle>
                {unit.progress === 100 && <CheckCircle className="h-6 w-6 text-green-500" />}
              </div>
              <CardDescription className="text-base">
                {unit.description}
              </CardDescription>
              <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                <span className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  {unit.estimatedMinutes} minutes
                </span>
                <span>{unit.cluster}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-blue-600 mb-1">
                {unit.progress}%
              </div>
              <div className="text-sm text-gray-500">Complete</div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Progress value={unit.progress} className="h-3" />
        </CardContent>
      </Card>

      {/* Lessons */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Lessons</h2>
        <div className="grid gap-4">
          {unit.lessons.map((lesson, index) => {
            const Icon = lessonIcons[lesson.type as keyof typeof lessonIcons]
            const colorClass = lessonColors[lesson.type as keyof typeof lessonColors]
            
            return (
              <Card key={lesson.id} className={`hover:shadow-md transition-shadow ${lesson.completed ? 'bg-green-50 border-green-200' : ''}`}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 ${colorClass} rounded-lg flex items-center justify-center`}>
                        {lesson.completed ? (
                          <CheckCircle className="h-6 w-6 text-white" />
                        ) : (
                          <Icon className="h-6 w-6 text-white" />
                        )}
                      </div>
                      <div>
                        <h3 className="font-medium">{lesson.title}</h3>
                        <div className="flex items-center space-x-3 mt-1 text-sm text-gray-500">
                          <span className="flex items-center">
                            <Clock className="h-3 w-3 mr-1" />
                            {lesson.duration} min
                          </span>
                          <span className="flex items-center">
                            <Star className="h-3 w-3 mr-1" />
                            {lesson.xp} XP
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {lesson.completed && (
                        <Badge variant="secondary" className="text-green-700 bg-green-100">
                          Completed
                        </Badge>
                      )}
                      <Button 
                        size="sm"
                        variant={lesson.completed ? "outline" : "default"}
                        onClick={() => {
                          toast.success(`${lesson.completed ? 'Reviewing' : 'Starting'} lesson: ${lesson.title}`)
                        }}
                      >
                        {lesson.completed ? 'Review' : 'Start'}
                        <Play className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>

      {/* Continue Button */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
        <CardContent className="p-6 text-center">
          <h3 className="text-lg font-semibold mb-2">
            {unit.progress === 100 ? 'Unit Complete!' : 'Continue Learning'}
          </h3>
          <p className="text-gray-600 mb-4">
            {unit.progress === 100 
              ? 'Great job! You can review lessons or move to the next unit.'
              : 'Keep going to master this unit.'
            }
          </p>
          <div className="space-x-3">
            <Button asChild>
              <Link href="/learn">
                {unit.progress === 100 ? 'Next Unit' : 'Continue'}
              </Link>
            </Button>
            {unit.progress > 0 && (
              <Button 
                variant="outline"
                onClick={() => {
                  toast.success('Starting lesson review! This is a demo.')
                }}
              >
                Review Lessons
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
