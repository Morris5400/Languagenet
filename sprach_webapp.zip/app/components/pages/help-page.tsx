
'use client'

import { useState, useEffect } from 'react'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useLanguage } from '@/components/providers/language-provider'
import { t } from '@/lib/i18n'
import { 
  Search,
  Heart,
  Target,
  Smartphone,
  RotateCcw,
  Download,
  AlertCircle,
  BookOpen,
  Settings,
  MessageSquare
} from 'lucide-react'

// Mock FAQ data - would come from API
const faqData = [
  {
    id: '1',
    category: 'hearts',
    question: 'How does the heart system work?',
    answer: 'You start with 5 hearts each day. When you make a mistake in a lesson, you lose one heart. Hearts refill every 4 hours, or you can practice old lessons to earn them back faster.',
    icon: Heart,
    tags: ['hearts', 'lives', 'mistakes']
  },
  {
    id: '2',
    category: 'goals',
    question: 'How to set or change my daily goal?',
    answer: 'Go to your Profile settings and adjust your daily goal. You can choose between 5, 10, 15, 20, or 30 minutes per day. Start small and build consistency!',
    icon: Target,
    tags: ['goal', 'daily', 'minutes', 'settings']
  },
  {
    id: '3',
    category: 'offline',
    question: 'How to use offline lessons?',
    answer: 'Most lessons work offline after you\'ve downloaded them. Look for the download icon next to lessons. Note: Video lessons require an internet connection.',
    icon: Smartphone,
    tags: ['offline', 'download', 'internet', 'video']
  },
  {
    id: '4',
    category: 'srs',
    question: 'What is SRS and why is it helpful?',
    answer: 'SRS (Spaced Repetition System) is a learning technique that shows you cards at increasing intervals. It\'s scientifically proven to improve long-term retention by up to 200%.',
    icon: RotateCcw,
    tags: ['srs', 'spaced', 'repetition', 'memory', 'retention']
  },
  {
    id: '5',
    category: 'data',
    question: 'How to delete or export my data?',
    answer: 'Go to Settings > Privacy & Data. You can download all your data or request account deletion. Data exports include your progress, statistics, and learning history.',
    icon: Download,
    tags: ['data', 'privacy', 'export', 'delete', 'gdpr']
  },
  {
    id: '6',
    category: 'bugs',
    question: 'How to report bugs or content issues?',
    answer: 'Use the Contact form to report bugs or incorrect content. Include screenshots when possible. We typically respond within 24 hours and fix issues in our next update.',
    icon: AlertCircle,
    tags: ['bugs', 'issues', 'contact', 'report', 'feedback']
  }
]

const categories = [
  { id: 'all', name: 'All Topics', icon: BookOpen, count: faqData.length },
  { id: 'hearts', name: 'Hearts & Lives', icon: Heart, count: 1 },
  { id: 'goals', name: 'Goals & Progress', icon: Target, count: 1 },
  { id: 'offline', name: 'Offline Features', icon: Smartphone, count: 1 },
  { id: 'srs', name: 'SRS & Review', icon: RotateCcw, count: 1 },
  { id: 'data', name: 'Data & Privacy', icon: Download, count: 1 },
  { id: 'bugs', name: 'Bug Reports', icon: AlertCircle, count: 1 }
]

export default function HelpPage() {
  const { language } = useLanguage()
  const [mounted, setMounted] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [filteredFAQs, setFilteredFAQs] = useState(faqData)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    let filtered = faqData

    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(faq => faq.category === selectedCategory)
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(faq => 
        faq.question.toLowerCase().includes(query) ||
        faq.answer.toLowerCase().includes(query) ||
        faq.tags.some(tag => tag.toLowerCase().includes(query))
      )
    }

    setFilteredFAQs(filtered)
  }, [searchQuery, selectedCategory])

  if (!mounted) {
    return <div className="flex items-center justify-center min-h-[50vh]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
    </div>
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          {t('nav.help', language)} Center
        </h1>
        <p className="text-gray-600">
          Find answers to common questions and learn how to use LanguageLearner
        </p>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder={t('help.searchPlaceholder', language)}
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Categories Sidebar */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">{t('help.categories', language)}</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="space-y-1">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`w-full flex items-center justify-between p-3 text-left hover:bg-gray-50 transition-colors ${
                      selectedCategory === category.id ? 'bg-blue-50 border-r-2 border-blue-500' : ''
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <category.icon className="h-4 w-4 text-gray-500" />
                      <span className="text-sm">{category.name}</span>
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {category.id === 'all' ? filteredFAQs.length : category.count}
                    </Badge>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* FAQ Content */}
        <div className="lg:col-span-3 space-y-6">
          {filteredFAQs.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  No results found
                </h3>
                <p className="text-gray-600">
                  Try adjusting your search terms or browsing by category.
                </p>
              </CardContent>
            </Card>
          ) : (
            filteredFAQs.map((faq) => (
              <Card key={faq.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <faq.icon className="h-5 w-5 text-blue-600" />
                    <span>{faq.question}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 leading-relaxed mb-4">
                    {faq.answer}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {faq.tags.map((tag, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      {/* Still Need Help */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <CardContent className="p-6 text-center">
          <MessageSquare className="h-8 w-8 text-blue-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Still need help?
          </h3>
          <p className="text-gray-600 mb-4">
            Can't find what you're looking for? Our support team is here to help.
          </p>
          <div className="flex flex-col sm:flex-row gap-2 justify-center">
            <button 
              onClick={() => window.location.href = '/contact'}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Contact Support
            </button>
            <button 
              onClick={() => {
                // Trigger chat tutor opening - would integrate with ChatTutor component
                const chatEvent = new CustomEvent('openChatTutor', { detail: { message: 'I need help with something' } })
                window.dispatchEvent(chatEvent)
              }}
              className="px-4 py-2 border border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50 transition-colors"
            >
              Chat with AI Tutor
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
