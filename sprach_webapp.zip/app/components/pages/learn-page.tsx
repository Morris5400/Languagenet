
'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useSession } from 'next-auth/react'
import { useGuest } from '@/components/providers/guest-provider'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useLanguage } from '@/components/providers/language-provider'
import { t, languagePairs } from '@/lib/i18n'
import { 
  BookOpen,
  Brain,
  Play,
  Video,
  MessageSquare,
  Lock,
  CheckCircle,
  Clock,
  Target,
  Star,
  Globe,
  Zap,
  Heart
} from 'lucide-react'

// Mock data - this would come from your database/API
const clusters = [
  {
    id: '1',
    slug: 'daily-life',
    title: 'Daily Life & Basics',
    description: 'Essential vocabulary and phrases for everyday situations',
    icon: '🏠',
    level: 'A1',
    progress: 45,
    units: [
      {
        id: '1',
        title: 'Greetings & Introductions',
        progress: 100,
        lessons: 3,
        completedLessons: 3,
        estimatedMinutes: 15,
        locked: false
      },
      {
        id: '2',
        title: 'Family & Friends',
        progress: 67,
        lessons: 3,
        completedLessons: 2,
        estimatedMinutes: 20,
        locked: false
      },
      {
        id: '3',
        title: 'Home & Living',
        progress: 0,
        lessons: 3,
        completedLessons: 0,
        estimatedMinutes: 18,
        locked: false
      }
    ]
  },
  {
    id: '2',
    slug: 'travel-transport',
    title: 'Travel & Transportation',
    description: 'Navigate and communicate while traveling',
    icon: '✈️',
    level: 'A2',
    progress: 12,
    units: [
      {
        id: '4',
        title: 'At the Airport',
        progress: 33,
        lessons: 3,
        completedLessons: 1,
        estimatedMinutes: 22,
        locked: false
      },
      {
        id: '5',
        title: 'Hotels & Accommodation',
        progress: 0,
        lessons: 3,
        completedLessons: 0,
        estimatedMinutes: 25,
        locked: false
      },
      {
        id: '6',
        title: 'Public Transportation',
        progress: 0,
        lessons: 3,
        completedLessons: 0,
        estimatedMinutes: 20,
        locked: false
      }
    ]
  },
  {
    id: '3',
    slug: 'business-work',
    title: 'Business & Work',
    description: 'Professional communication and workplace vocabulary',
    icon: '💼',
    level: 'B1',
    progress: 0,
    units: [
      {
        id: '7',
        title: 'Job Interviews',
        progress: 0,
        lessons: 3,
        completedLessons: 0,
        estimatedMinutes: 30,
        locked: true
      },
      {
        id: '8',
        title: 'Office Communication',
        progress: 0,
        lessons: 3,
        completedLessons: 0,
        estimatedMinutes: 25,
        locked: true
      },
      {
        id: '9',
        title: 'Business Presentations',
        progress: 0,
        lessons: 3,
        completedLessons: 0,
        estimatedMinutes: 35,
        locked: true
      }
    ]
  }
]

const lessonTypes = [
  {
    type: 'VOCAB_SPRINT',
    name: 'Vocabulary Sprint',
    icon: Brain,
    color: 'bg-blue-500',
    description: 'Quick vocabulary practice with mnemonics'
  },
  {
    type: 'STRUCTURE_DRILL',
    name: 'Grammar Drill',
    icon: Target,
    color: 'bg-green-500',
    description: 'Master grammar patterns and structures'
  },
  {
    type: 'VIDEO_IMMERSION',
    name: 'Video Immersion',
    icon: Video,
    color: 'bg-purple-500',
    description: 'Learn from authentic video content'
  },
  {
    type: 'DIALOG_ROLEPLAY',
    name: 'Dialog Practice',
    icon: MessageSquare,
    color: 'bg-orange-500',
    description: 'Practice real conversations'
  }
]

export default function LearnPage() {
  const { data: session } = useSession()
  const { isGuest, progress, updateProgress } = useGuest()
  const { language } = useLanguage()
  const [mounted, setMounted] = useState(false)
  const [selectedLanguagePair, setSelectedLanguagePair] = useState('de-en')

  useEffect(() => {
    setMounted(true)
    if (isGuest && progress.selectedLanguagePair) {
      setSelectedLanguagePair(progress.selectedLanguagePair)
    }
  }, [isGuest, progress.selectedLanguagePair])

  const handleLanguagePairChange = (value: string) => {
    setSelectedLanguagePair(value)
    if (isGuest) {
      updateProgress({ selectedLanguagePair: value })
    }
  }

  if (!mounted) {
    return <div className="flex items-center justify-center min-h-[50vh]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
    </div>
  }

  return (
    <div className="space-y-6 sm:space-y-8 px-4 sm:px-0">
      {/* Header Section */}
      <div className="text-center space-y-4">
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">
          {t('nav.learn', language)}
        </h1>
        <p className="text-gray-600 text-sm sm:text-base">
          Choose a topic cluster and start your language learning journey
        </p>
        
        {/* Language Pair Selector */}
        <div className="flex flex-col items-center space-y-2">
          <label className="text-sm font-medium text-gray-700">
            Choose Language Pair:
          </label>
          <Select value={selectedLanguagePair} onValueChange={handleLanguagePairChange}>
            <SelectTrigger className="w-full max-w-[280px]">
              <SelectValue placeholder="Select language pair" />
            </SelectTrigger>
            <SelectContent>
              {languagePairs.map((pair) => (
                <SelectItem key={pair.code} value={pair.code}>
                  {pair.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Stats Section - Mobile Optimized */}
      {(isGuest || session) && (
        <div className="grid grid-cols-3 gap-2 sm:gap-4 max-w-sm mx-auto">
          <div className="text-center bg-red-50 rounded-lg p-3">
            <div className="flex items-center justify-center text-red-500 mb-1">
              <Heart className="h-4 w-4 sm:h-5 sm:w-5 mr-1 fill-current" />
              <span className="font-bold text-sm sm:text-lg">{isGuest ? progress.hearts : 5}</span>
            </div>
            <div className="text-xs text-gray-600">Hearts</div>
          </div>
          <div className="text-center bg-yellow-50 rounded-lg p-3">
            <div className="flex items-center justify-center text-yellow-500 mb-1">
              <Zap className="h-4 w-4 sm:h-5 sm:w-5 mr-1" />
              <span className="font-bold text-sm sm:text-lg">{isGuest ? progress.xp : 1250}</span>
            </div>
            <div className="text-xs text-gray-600">XP</div>
          </div>
          <div className="text-center bg-orange-50 rounded-lg p-3">
            <div className="flex items-center justify-center text-orange-500 mb-1">
              <Star className="h-4 w-4 sm:h-5 sm:w-5 mr-1" />
              <span className="font-bold text-sm sm:text-lg">{isGuest ? progress.streak : 7}</span>
            </div>
            <div className="text-xs text-gray-600">Streak</div>
          </div>
        </div>
      )}

      {/* Current Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Target className="h-5 w-5" />
            <span>Your Learning Path</span>
          </CardTitle>
          <CardDescription>
            Track your progress across different skill areas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between text-sm">
              <span>Overall Progress</span>
              <span className="text-blue-600">Level A2 • 19% Complete</span>
            </div>
            <Progress value={19} className="h-3" />
            <div className="text-xs text-gray-500">
              Keep learning to unlock higher level content!
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Topic Clusters */}
      <div className="space-y-6">
        {clusters.map((cluster) => (
          <Card key={cluster.id} className="overflow-hidden">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="text-3xl">{cluster.icon}</div>
                  <div>
                    <CardTitle className="flex items-center space-x-2">
                      <span>{cluster.title}</span>
                      <Badge variant="outline">{cluster.level}</Badge>
                    </CardTitle>
                    <CardDescription>{cluster.description}</CardDescription>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-blue-600">
                    {cluster.progress}%
                  </div>
                  <div className="text-xs text-gray-500">Complete</div>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="pt-0">
              <div className="grid gap-4 md:grid-cols-3">
                {cluster.units.map((unit) => (
                  <Card key={unit.id} className={`relative ${unit.locked ? 'opacity-50' : 'hover:shadow-md'} transition-shadow`}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-medium text-sm">{unit.title}</h3>
                        {unit.locked ? (
                          <Lock className="h-4 w-4 text-gray-400" />
                        ) : unit.progress === 100 ? (
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        ) : (
                          <Play className="h-4 w-4 text-blue-500" />
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs text-gray-500">
                          <span>{unit.completedLessons}/{unit.lessons} lessons</span>
                          <span className="flex items-center">
                            <Clock className="h-3 w-3 mr-1" />
                            {unit.estimatedMinutes}min
                          </span>
                        </div>
                        
                        <Progress value={unit.progress} className="h-1.5" />
                        
                        <div className="pt-2">
                          <Button 
                            size="sm" 
                            className="w-full"
                            variant={unit.locked ? "ghost" : "default"}
                            disabled={unit.locked}
                            asChild={!unit.locked}
                          >
                            {unit.locked ? (
                              <span>Locked</span>
                            ) : (
                              <Link href={`/learn/unit/${unit.id}`}>
                                {unit.progress === 0 ? 'Start' : 'Continue'}
                              </Link>
                            )}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Lesson Types Info */}
      <Card>
        <CardHeader>
          <CardTitle>Lesson Types</CardTitle>
          <CardDescription>
            Different ways to learn and practice your target language
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {lessonTypes.map((type) => (
              <div key={type.type} className="text-center space-y-2">
                <div className={`w-12 h-12 ${type.color} rounded-lg flex items-center justify-center mx-auto`}>
                  <type.icon className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-medium">{type.name}</h3>
                  <p className="text-xs text-gray-600">{type.description}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
