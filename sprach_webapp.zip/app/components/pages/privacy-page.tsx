
'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useLanguage } from '@/components/providers/language-provider'
import { Shield, Eye, Lock, Download, Mail, Globe } from 'lucide-react'

export default function PrivacyPage() {
  const { language } = useLanguage()

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center">
        <div className="flex items-center justify-center space-x-2 mb-4">
          <Shield className="h-8 w-8 text-blue-600" />
          <h1 className="text-3xl font-bold text-gray-900">Privacy Policy</h1>
          <Badge variant="secondary">Beta</Badge>
        </div>
        <p className="text-gray-600">
          Your privacy is important to us. This policy explains how we collect, use, and protect your data.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Eye className="h-5 w-5" />
            <span>Data We Collect</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div>
              <h3 className="font-medium">Account Information</h3>
              <p className="text-sm text-gray-600">Email, username, name, and authentication data</p>
            </div>
            <div>
              <h3 className="font-medium">Learning Progress</h3>
              <p className="text-sm text-gray-600">Lesson completions, scores, streaks, and study statistics</p>
            </div>
            <div>
              <h3 className="font-medium">Usage Data</h3>
              <p className="text-sm text-gray-600">App usage patterns, feature interactions, and performance data</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Lock className="h-5 w-5" />
            <span>How We Use Your Data</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-start space-x-3">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
            <div>
              <h3 className="font-medium">Personalized Learning</h3>
              <p className="text-sm text-gray-600">To adapt lessons to your learning style and progress</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
            <div>
              <h3 className="font-medium">Account Management</h3>
              <p className="text-sm text-gray-600">To maintain your account, authenticate you, and provide support</p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
            <div>
              <h3 className="font-medium">Service Improvement</h3>
              <p className="text-sm text-gray-600">To improve our app features and user experience</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Download className="h-5 w-5" />
            <span>Your Rights (GDPR Compliant)</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-3 bg-blue-50 rounded-lg">
              <h3 className="font-medium text-blue-800">Right to Access</h3>
              <p className="text-sm text-blue-600">Request a copy of your personal data</p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg">
              <h3 className="font-medium text-green-800">Right to Rectification</h3>
              <p className="text-sm text-green-600">Correct inaccurate personal data</p>
            </div>
            <div className="p-3 bg-orange-50 rounded-lg">
              <h3 className="font-medium text-orange-800">Right to Erasure</h3>
              <p className="text-sm text-orange-600">Request deletion of your data</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg">
              <h3 className="font-medium text-purple-800">Right to Portability</h3>
              <p className="text-sm text-purple-600">Export your data in a portable format</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Globe className="h-5 w-5" />
            <span>Data Security</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">
            We use industry-standard encryption and security measures to protect your data. 
            All passwords are securely hashed, and sensitive information is encrypted in transit and at rest.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Mail className="h-5 w-5" />
            <span>Contact Us</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 mb-4">
            If you have any questions about this Privacy Policy or want to exercise your rights, please contact us:
          </p>
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="font-medium">Email: morrispoyotte@gmail.com</p>
            <p className="text-sm text-gray-600">We respond to privacy requests within 30 days</p>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <p className="text-sm text-blue-800">
            <strong>Last updated:</strong> August 2024 • This is a Beta version of our Privacy Policy. 
            We may update this policy as we add new features and improve our service.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
