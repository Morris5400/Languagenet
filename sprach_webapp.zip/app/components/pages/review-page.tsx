
'use client'

import { useState, useEffect } from 'react'
import { toast } from 'sonner'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { useLanguage } from '@/components/providers/language-provider'
import { t } from '@/lib/i18n'
import { 
  RotateCcw,
  Clock,
  Target,
  Brain,
  CheckCircle,
  XCircle,
  Calendar,
  Zap,
  TrendingUp,
  Play
} from 'lucide-react'

// Mock SRS data - would come from API
const reviewData = {
  dueToday: 23,
  overdue: 5,
  newCards: 12,
  masteredToday: 8,
  accuracyToday: 78,
  streakDays: 7,
  totalReviews: 156,
  categories: [
    { name: 'Vocabulary', due: 15, color: 'bg-blue-500' },
    { name: 'Grammar', due: 6, color: 'bg-green-500' },
    { name: 'Phrases', due: 2, color: 'bg-purple-500' }
  ],
  recentCards: [
    {
      id: '1',
      question: 'How do you say "good morning" in German?',
      answer: 'Guten Morgen',
      lastReview: '2 hours ago',
      nextReview: 'in 1 day',
      difficulty: 'Easy',
      streak: 3
    },
    {
      id: '2',
      question: 'Translate: "Ich bin müde"',
      answer: 'I am tired',
      lastReview: '5 hours ago',
      nextReview: 'in 2 days',
      difficulty: 'Medium',
      streak: 1
    }
  ]
}

export default function ReviewPage() {
  const { language } = useLanguage()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <div className="flex items-center justify-center min-h-[50vh]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
    </div>
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          {t('nav.review', language)} - SRS System
        </h1>
        <p className="text-gray-600">
          Review cards using spaced repetition to maximize your retention
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="text-center">
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl font-bold text-red-600">
              {reviewData.dueToday}
            </CardTitle>
            <CardDescription>Due Today</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex justify-center">
              <Clock className="h-5 w-5 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl font-bold text-orange-600">
              {reviewData.overdue}
            </CardTitle>
            <CardDescription>Overdue</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex justify-center">
              <Target className="h-5 w-5 text-orange-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl font-bold text-blue-600">
              {reviewData.newCards}
            </CardTitle>
            <CardDescription>New Cards</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex justify-center">
              <Brain className="h-5 w-5 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl font-bold text-green-600">
              {reviewData.accuracyToday}%
            </CardTitle>
            <CardDescription>Today's Accuracy</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex justify-center">
              <TrendingUp className="h-5 w-5 text-green-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Start Review */}
      <Card className="text-center bg-gradient-to-r from-blue-50 to-purple-50">
        <CardContent className="py-8">
          <div className="space-y-4">
            <div className="text-6xl">🧠</div>
            <h2 className="text-2xl font-bold">Ready to Review?</h2>
            <p className="text-gray-600">
              {reviewData.dueToday + reviewData.overdue} cards are waiting for your attention
            </p>
            <div className="space-y-3">
              <Button 
                size="lg" 
                className="px-8"
                onClick={() => {
                  // In a real app, this would start the review session
                  toast.success('Review session started! This is a demo.')
                }}
              >
                <Play className="mr-2 h-5 w-5" />
                Start Review Session
              </Button>
              <div className="text-sm text-gray-500">
                Estimated time: {Math.ceil((reviewData.dueToday + reviewData.overdue) * 0.5)} minutes
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Review Categories */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <RotateCcw className="h-5 w-5" />
            <span>Review Categories</span>
          </CardTitle>
          <CardDescription>
            Cards organized by type and difficulty
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {reviewData.categories.map((category, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-4 h-4 ${category.color} rounded-full`}></div>
                  <div>
                    <h3 className="font-medium">{category.name}</h3>
                    <p className="text-sm text-gray-500">{category.due} cards due</p>
                  </div>
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    toast.success(`Starting ${category.name} review! This is a demo.`)
                  }}
                >
                  Review {category.due}
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Progress Insights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5" />
              <span>Weekly Progress</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm">This Week</span>
                <span className="font-medium">{reviewData.totalReviews} reviews</span>
              </div>
              <Progress value={65} />
              <div className="text-xs text-gray-500">
                65% of weekly goal (240 reviews)
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Zap className="h-5 w-5" />
              <span>Streak Stats</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center space-y-2">
              <div className="text-3xl font-bold text-orange-500">
                {reviewData.streakDays}
              </div>
              <p className="text-sm text-gray-600">Day Streak</p>
              <div className="flex justify-center space-x-1">
                {Array.from({ length: 7 }, (_, i) => (
                  <div 
                    key={i}
                    className={`w-4 h-4 rounded-full ${
                      i < reviewData.streakDays ? 'bg-orange-500' : 'bg-gray-200'
                    }`}
                  />
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Cards */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Review History</CardTitle>
          <CardDescription>
            Your last reviewed cards and their performance
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {reviewData.recentCards.map((card) => (
              <div key={card.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex-1">
                  <p className="font-medium text-sm">{card.question}</p>
                  <p className="text-sm text-gray-600">{card.answer}</p>
                  <div className="flex items-center space-x-4 mt-1 text-xs text-gray-500">
                    <span>Last: {card.lastReview}</span>
                    <span>Next: {card.nextReview}</span>
                    <span>Streak: {card.streak}</span>
                  </div>
                </div>
                <div className="text-right">
                  <Badge 
                    variant={card.difficulty === 'Easy' ? 'default' : card.difficulty === 'Medium' ? 'secondary' : 'destructive'}
                  >
                    {card.difficulty}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* SRS Explanation */}
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-blue-800">
            <Brain className="h-5 w-5" />
            <span>What is SRS?</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="text-blue-700">
          <p className="text-sm leading-relaxed">
            Spaced Repetition System (SRS) is a learning technique that presents information at increasing intervals. 
            Cards you find easy appear less frequently, while difficult cards appear more often. This scientifically-proven 
            method maximizes long-term retention while minimizing study time.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
