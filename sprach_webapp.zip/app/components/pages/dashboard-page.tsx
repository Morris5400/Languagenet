
'use client'

import { useState, useEffect } from 'react'
import { toast } from 'sonner'
import { useSession } from 'next-auth/react'
import { useGuest } from '@/components/providers/guest-provider'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { useLanguage } from '@/components/providers/language-provider'
import { t, languagePairs } from '@/lib/i18n'
import { 
  BookOpen,
  Brain,
  MessageSquare,
  Trophy,
  Calendar,
  Clock,
  Target,
  Play,
  RotateCcw,
  ArrowRight,
  Heart,
  Zap,
  Flame,
  UserCheck
} from 'lucide-react'

export default function DashboardPage() {
  const { data: session } = useSession() || {}
  const { isGuest, progress } = useGuest()
  const { language } = useLanguage()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return <div className="flex items-center justify-center min-h-[50vh]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
    </div>
  }

  const userName = session?.user?.name || (isGuest ? 'Guest' : '')

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Welcome back{userName ? `, ${userName}` : ''}! 👋
          {isGuest && <span className="ml-2"><Badge variant="outline">Guest Mode</Badge></span>}
        </h1>
        <p className="text-gray-600">
          Ready to continue your language learning journey?
        </p>
      </div>

      {/* Guest Mode Info */}
      {isGuest && (
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-3">
              <UserCheck className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-sm font-medium text-blue-900">
                  You're learning as a guest
                </p>
                <p className="text-xs text-blue-700">
                  Create an account to save your progress permanently and sync across devices
                </p>
              </div>
              <Button variant="outline" size="sm" asChild className="ml-auto">
                <Link href="/auth/signup">Sign Up</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Streak</CardTitle>
            <Flame className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-500">
              {isGuest ? progress.streak : '7'} days
            </div>
            <p className="text-xs text-muted-foreground">
              {progress.streak > 0 ? 'Keep it up! 🔥' : 'Start your streak today! 💪'}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total XP</CardTitle>
            <Zap className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-500">
              {isGuest ? progress.xp : '1,250'}
            </div>
            <p className="text-xs text-muted-foreground">
              {isGuest && progress.xp === 0 ? 'Start learning to earn XP!' : '+50 XP today'}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Hearts</CardTitle>
            <Heart className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-500">
              {isGuest ? progress.hearts : '5'}/5
            </div>
            <p className="text-xs text-muted-foreground">
              {isGuest && progress.hearts === 5 ? 'Full hearts ❤️' : 
               isGuest && progress.hearts < 5 ? 'Hearts refill over time' : 'Full hearts ❤️'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card 
          className="hover:shadow-lg transition-shadow cursor-pointer"
          onClick={() => window.location.href = '/learn'}
        >
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Play className="h-5 w-5 text-blue-600" />
              <CardTitle className="text-lg">Continue Learning</CardTitle>
            </div>
            <CardDescription>
              Pick up where you left off
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Unit: Daily Conversations</span>
                <span className="text-blue-600">A2</span>
              </div>
              <Progress value={65} className="h-2" />
              <p className="text-xs text-gray-500">2/3 lessons completed</p>
            </div>
            <Button className="w-full mt-4" asChild>
              <Link href="/learn">
                Continue
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card 
          className="hover:shadow-lg transition-shadow cursor-pointer"
          onClick={() => window.location.href = '/review'}
        >
          <CardHeader>
            <div className="flex items-center space-x-2">
              <RotateCcw className="h-5 w-5 text-green-600" />
              <CardTitle className="text-lg">Review Cards</CardTitle>
            </div>
            <CardDescription>
              23 cards ready for review
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Due cards</span>
                <Badge variant="outline">23</Badge>
              </div>
              <div className="flex justify-between text-sm">
                <span>Overdue</span>
                <Badge variant="destructive">5</Badge>
              </div>
            </div>
            <Button className="w-full mt-4" variant="outline" asChild>
              <Link href="/review">
                Start Review
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card 
          className="hover:shadow-lg transition-shadow cursor-pointer"
          onClick={() => {
            const chatEvent = new CustomEvent('openChatTutor', { detail: { message: 'Hi! I\'d like to practice with you.' } })
            window.dispatchEvent(chatEvent)
          }}
        >
          <CardHeader>
            <div className="flex items-center space-x-2">
              <MessageSquare className="h-5 w-5 text-purple-600" />
              <CardTitle className="text-lg">Chat Tutor</CardTitle>
            </div>
            <CardDescription>
              Practice with AI tutor
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              Get instant help, practice conversations, or ask questions about your current lesson.
            </p>
            <Button 
              className="w-full" 
              variant="outline"
              onClick={() => {
                // Trigger chat tutor opening
                const chatEvent = new CustomEvent('openChatTutor', { detail: { message: 'Hi! I\'d like to practice with you.' } })
                window.dispatchEvent(chatEvent)
              }}
            >
              Start Chat
              <MessageSquare className="ml-2 h-4 w-4" />
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Current Language Pair */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Target className="h-5 w-5" />
            <span>Current Language Pair</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {languagePairs.map((pair) => (
              <Card 
                key={pair.code} 
                className={`cursor-pointer transition-colors hover:bg-gray-50 ${
                  pair.code === 'de-en' ? 'border-blue-500 bg-blue-50' : ''
                }`}
                onClick={() => {
                  toast.success(`Selected language pair: ${pair.name}`)
                }}
              >
                <CardContent className="p-4 text-center">
                  <div className="text-2xl mb-2">
                    {pair.code === 'hu-de' && '🇭🇺 ↔ 🇩🇪'}
                    {pair.code === 'hu-en' && '🇭🇺 ↔ 🇺🇸'}
                    {pair.code === 'de-en' && '🇩🇪 ↔ 🇺🇸'}
                  </div>
                  <p className="font-medium">{pair.name}</p>
                  {pair.code === 'de-en' && (
                    <Badge className="mt-2">Active</Badge>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Daily Goal Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="h-5 w-5" />
            <span>Daily Goal</span>
          </CardTitle>
          <CardDescription>
            Keep up the momentum with daily practice
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Today's Progress</span>
              <span className="text-sm text-gray-500">8 / 15 minutes</span>
            </div>
            <Progress value={53} className="h-3" />
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <Clock className="h-4 w-4" />
              <span>7 more minutes to reach your daily goal</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Achievements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="h-5 w-5" />
            <span>Recent Achievements</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-lg">
              <div className="text-2xl">🔥</div>
              <div>
                <p className="font-medium">Week Warrior</p>
                <p className="text-sm text-gray-600">7 day streak completed</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
              <div className="text-2xl">📚</div>
              <div>
                <p className="font-medium">Lesson Master</p>
                <p className="text-sm text-gray-600">10 lessons completed</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
              <div className="text-2xl">🎯</div>
              <div>
                <p className="font-medium">Perfect Score</p>
                <p className="text-sm text-gray-600">100% accuracy in lesson</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
