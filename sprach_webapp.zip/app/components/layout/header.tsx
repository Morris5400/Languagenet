
'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'
import { useGuest } from '@/components/providers/guest-provider'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu'
import { useLanguage } from '@/components/providers/language-provider'
import { t, languages } from '@/lib/i18n'
import { 
  User, 
  Settings, 
  LogOut, 
  Globe, 
  Heart, 
  Zap, 
  Flame,
  Menu,
  X,
  UserPlus
} from 'lucide-react'

export default function Header() {
  const { data: session } = useSession() || {}
  const { isGuest, progress } = useGuest()
  const { language, setLanguage } = useLanguage()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-sm">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        {/* Logo & Beta Badge */}
        <div className="flex items-center space-x-2">
          <Link href={session || isGuest ? "/dashboard" : "/"} className="flex items-center space-x-2">
            <div className="rounded-lg bg-gradient-to-br from-blue-600 to-purple-600 p-2">
              <Globe className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900">LanguageLearner</span>
          </Link>
          <Badge variant="secondary" className="text-xs">
            {t('common.beta', language)}
          </Badge>
          <Badge variant="outline" className="text-xs text-green-600">
            {t('common.free', language)}
          </Badge>
          {isGuest && (
            <Badge variant="outline" className="text-xs text-blue-600">
              Guest Mode
            </Badge>
          )}
        </div>

        {/* Desktop Navigation - Show for both logged in users and guests */}
        {(session || isGuest) && (
          <nav className="hidden md:flex items-center space-x-6">
            <Link 
              href="/dashboard" 
              className="text-gray-600 hover:text-gray-900 transition-colors"
            >
              {t('nav.home', language)}
            </Link>
            <Link 
              href="/learn" 
              className="text-gray-600 hover:text-gray-900 transition-colors"
            >
              {t('nav.learn', language)}
            </Link>
            <Link 
              href="/review" 
              className="text-gray-600 hover:text-gray-900 transition-colors"
            >
              {t('nav.review', language)}
            </Link>
            <Link 
              href="/help" 
              className="text-gray-600 hover:text-gray-900 transition-colors"
            >
              {t('nav.help', language)}
            </Link>
          </nav>
        )}

        {/* User Actions */}
        <div className="flex items-center space-x-4">
          {/* Language Selector - Simplified for testing */}
          <div className="flex items-center space-x-1">
            {languages.map((lang) => (
              <Button
                key={lang.code}
                variant={language === lang.code ? "default" : "ghost"}
                size="sm"
                onClick={() => setLanguage(lang.code)}
                className="px-2"
              >
                {lang.flag}
              </Button>
            ))}
          </div>

          {(session || isGuest) ? (
            <>
              {/* User Stats - Desktop Only */}
              <div className="hidden md:flex items-center space-x-3 text-sm">
                <div className="flex items-center text-red-500">
                  <Heart className="h-4 w-4 mr-1 fill-current" />
                  <span>{isGuest ? progress.hearts : '5'}</span>
                </div>
                <div className="flex items-center text-yellow-500">
                  <Zap className="h-4 w-4 mr-1" />
                  <span>{isGuest ? progress.xp : '1,250'}</span>
                </div>
                <div className="flex items-center text-orange-500">
                  <Flame className="h-4 w-4 mr-1" />
                  <span>{isGuest ? progress.streak : '7'}</span>
                </div>
              </div>

              {/* User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="relative">
                    <User className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {isGuest ? (
                    <>
                      <DropdownMenuItem asChild>
                        <Link href="/auth/signup">
                          <UserPlus className="h-4 w-4 mr-2" />
                          Sign Up
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/auth/signin">
                          <User className="h-4 w-4 mr-2" />
                          Sign In
                        </Link>
                      </DropdownMenuItem>
                    </>
                  ) : (
                    <>
                      <DropdownMenuItem asChild>
                        <Link href="/profile">
                          <Settings className="h-4 w-4 mr-2" />
                          {t('common.settings', language)}
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => signOut()}>
                        <LogOut className="h-4 w-4 mr-2" />
                        {t('common.logout', language)}
                      </DropdownMenuItem>
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <div className="flex items-center space-x-2">
              <Button variant="ghost" asChild>
                <Link href="/auth/signin">{t('auth.signIn', language)}</Link>
              </Button>
              <Button asChild>
                <Link href="/auth/signup">{t('auth.signUp', language)}</Link>
              </Button>
            </div>
          )}

          {/* Mobile Menu Button */}
          {(session || isGuest) && (
            <Button 
              variant="ghost" 
              size="sm" 
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </Button>
          )}
        </div>
      </div>

      {/* Mobile Menu */}
      {(session || isGuest) && mobileMenuOpen && (
        <div className="md:hidden border-t bg-white">
          <nav className="container mx-auto py-4 space-y-2">
            <Link 
              href="/dashboard" 
              className="block px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
              onClick={() => setMobileMenuOpen(false)}
            >
              {t('nav.home', language)}
            </Link>
            <Link 
              href="/learn" 
              className="block px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
              onClick={() => setMobileMenuOpen(false)}
            >
              {t('nav.learn', language)}
            </Link>
            <Link 
              href="/review" 
              className="block px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
              onClick={() => setMobileMenuOpen(false)}
            >
              {t('nav.review', language)}
            </Link>
            <Link 
              href="/help" 
              className="block px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg"
              onClick={() => setMobileMenuOpen(false)}
            >
              {t('nav.help', language)}
            </Link>
            
            {/* Mobile Stats */}
            <div className="flex items-center justify-around py-2 px-4 bg-gray-50 rounded-lg mx-4">
              <div className="flex items-center text-red-500">
                <Heart className="h-4 w-4 mr-1 fill-current" />
                <span>{isGuest ? progress.hearts : '5'}</span>
              </div>
              <div className="flex items-center text-yellow-500">
                <Zap className="h-4 w-4 mr-1" />
                <span>{isGuest ? progress.xp : '1,250'}</span>
              </div>
              <div className="flex items-center text-orange-500">
                <Flame className="h-4 w-4 mr-1" />
                <span>{isGuest ? progress.streak : '7'}</span>
              </div>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
