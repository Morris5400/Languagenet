
'use client'

import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { useSession } from 'next-auth/react'

interface GuestProgress {
  currentLevel: string
  completedUnits: string[]
  xp: number
  streak: number
  lastActiveDate: string
  hearts: number
  badges: string[]
  srsQueue: any[]
  lessonAttempts: any[]
  selectedLanguagePair: string
}

interface GuestContextType {
  isGuest: boolean
  progress: GuestProgress
  updateProgress: (updates: Partial<GuestProgress>) => void
  clearProgress: () => void
  exportProgress: () => string
  importProgress: (data: string) => boolean
}

const defaultProgress: GuestProgress = {
  currentLevel: 'A1',
  completedUnits: [],
  xp: 0,
  streak: 0,
  lastActiveDate: new Date().toISOString().split('T')[0],
  hearts: 5,
  badges: [],
  srsQueue: [],
  lessonAttempts: [],
  selectedLanguagePair: 'de-en'
}

const GuestContext = createContext<GuestContextType>({
  isGuest: true,
  progress: defaultProgress,
  updateProgress: () => {},
  clearProgress: () => {},
  exportProgress: () => '',
  importProgress: () => false
})

export const useGuest = () => {
  const context = useContext(GuestContext)
  if (!context) {
    throw new Error('useGuest must be used within GuestProvider')
  }
  return context
}

interface GuestProviderProps {
  children: ReactNode
}

export default function GuestProvider({ children }: GuestProviderProps) {
  const { data: session } = useSession()
  const [progress, setProgress] = useState<GuestProgress>(defaultProgress)
  const isGuest = !session

  // Load progress from localStorage on mount
  useEffect(() => {
    if (typeof window !== 'undefined' && isGuest) {
      const saved = localStorage.getItem('languageLearner_guestProgress')
      if (saved) {
        try {
          const parsedProgress = JSON.parse(saved)
          setProgress({ ...defaultProgress, ...parsedProgress })
        } catch (error) {
          console.error('Failed to load guest progress:', error)
        }
      }
    }
  }, [isGuest])

  // Save progress to localStorage whenever it changes
  useEffect(() => {
    if (typeof window !== 'undefined' && isGuest) {
      localStorage.setItem('languageLearner_guestProgress', JSON.stringify(progress))
    }
  }, [progress, isGuest])

  // Update daily streak and hearts
  useEffect(() => {
    if (isGuest) {
      const today = new Date().toISOString().split('T')[0]
      const lastActive = new Date(progress.lastActiveDate)
      const todayDate = new Date(today)
      const daysDiff = Math.floor((todayDate.getTime() - lastActive.getTime()) / (1000 * 60 * 60 * 24))
      
      if (daysDiff === 1) {
        // Consecutive day - maintain streak
        updateProgress({ lastActiveDate: today })
      } else if (daysDiff > 1) {
        // Streak broken
        updateProgress({ 
          streak: 0, 
          lastActiveDate: today,
          hearts: Math.min(progress.hearts + daysDiff, 5) // Restore some hearts
        })
      }
    }
  }, [isGuest])

  const updateProgress = (updates: Partial<GuestProgress>) => {
    setProgress(prev => ({ ...prev, ...updates }))
  }

  const clearProgress = () => {
    setProgress(defaultProgress)
    if (typeof window !== 'undefined') {
      localStorage.removeItem('languageLearner_guestProgress')
    }
  }

  const exportProgress = () => {
    return JSON.stringify(progress, null, 2)
  }

  const importProgress = (data: string): boolean => {
    try {
      const imported = JSON.parse(data)
      setProgress({ ...defaultProgress, ...imported })
      return true
    } catch (error) {
      console.error('Failed to import progress:', error)
      return false
    }
  }

  const value: GuestContextType = {
    isGuest,
    progress,
    updateProgress,
    clearProgress,
    exportProgress,
    importProgress
  }

  return (
    <GuestContext.Provider value={value}>
      {children}
    </GuestContext.Provider>
  )
}
