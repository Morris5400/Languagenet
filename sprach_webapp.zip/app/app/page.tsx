
import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import LandingPage from '@/components/pages/landing-page'

export default async function Home() {
  const session = await getServerSession(authOptions)

  // Only redirect if user is logged in, otherwise let them continue as guest
  if (session) {
    redirect('/dashboard')
  }

  return <LandingPage />
}
