
import PrivacyPage from '@/components/pages/privacy-page'

export default function Privacy() {
  return <PrivacyPage />
}
