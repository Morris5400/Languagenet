
import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import SessionProviderComponent from '@/components/providers/session-provider'
import LanguageProvider from '@/components/providers/language-provider'
import GuestProvider from '@/components/providers/guest-provider'
import { Toaster } from '@/components/ui/sonner'

const inter = Inter({ subsets: ['latin'] })

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#4f46e5'
}

export const metadata: Metadata = {
  title: 'LanguageLearner - Master Languages with AI (Beta)',
  description: 'Learn Hungarian, German, and English with AI-powered lessons, spaced repetition, and interactive content.',
  manifest: '/manifest.json',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'LanguageLearner (Beta)'
  },
  formatDetection: {
    telephone: false
  }
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <SessionProviderComponent>
          <GuestProvider>
            <LanguageProvider>
              <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
                {children}
              </div>
              <Toaster />
            </LanguageProvider>
          </GuestProvider>
        </SessionProviderComponent>
      </body>
    </html>
  )
}
