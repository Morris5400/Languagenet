
import SignInPage from '@/components/auth/signin-page'

export default function SignIn() {
  return <SignInPage />
}
