
import SignUpPage from '@/components/auth/signup-page'

export default function SignUp() {
  return <SignUpPage />
}
