
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import DashboardPage from '@/components/pages/dashboard-page'

export default async function Dashboard() {
  const session = await getServerSession(authOptions)
  
  return <DashboardPage />
}
