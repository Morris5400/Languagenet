
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import Header from '@/components/layout/header'
import ChatTutor from '@/components/chat/chat-tutor'

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const session = await getServerSession(authOptions)

  // Allow access for both authenticated users and guests
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        {children}
      </main>
      <ChatTutor />
    </div>
  )
}
