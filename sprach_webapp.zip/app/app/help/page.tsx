
import HelpPage from '@/components/pages/help-page'

export default function Help() {
  return <HelpPage />
}
