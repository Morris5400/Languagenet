
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import LearnPage from '@/components/pages/learn-page'

export default async function Learn() {
  const session = await getServerSession(authOptions)
  
  // Allow access for both authenticated users and guests
  return <LearnPage />
}
