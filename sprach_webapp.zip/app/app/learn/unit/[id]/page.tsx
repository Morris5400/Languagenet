
import { notFound } from 'next/navigation'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import UnitPage from '@/components/pages/unit-page'

interface Props {
  params: { id: string }
}

export default async function Unit({ params }: Props) {
  const session = await getServerSession(authOptions)
  
  // Allow access for both authenticated users and guests
  
  // In a real app, you'd fetch the unit data from your database
  // For now, we'll just check if the ID is valid
  const validIds = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
  
  if (!validIds.includes(params.id)) {
    notFound()
  }
  
  return <UnitPage unitId={params.id} />
}
