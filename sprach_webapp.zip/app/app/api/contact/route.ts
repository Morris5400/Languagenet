
import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    const body = await req.json()
    const { name, email, subject, message, language } = body

    // Validate required fields
    if (!name || !email || !subject || !message) {
      return NextResponse.json(
        { error: "All fields are required" },
        { status: 400 }
      )
    }

    // Save contact submission to database
    const submission = await db.contactSubmission.create({
      data: {
        name,
        email,
        subject,
        message,
        language: language || 'en',
        userId: session?.user?.id || null,
      }
    })

    // TODO: Send email notification to morrispoyotte@gmail.com
    // For now, we'll just log it
    console.log('New contact submission:', {
      id: submission.id,
      from: email,
      subject: subject,
      timestamp: submission.createdAt
    })

    return NextResponse.json({
      message: "Contact submission received successfully",
      id: submission.id
    })
  } catch (error) {
    console.error("Contact submission error:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
