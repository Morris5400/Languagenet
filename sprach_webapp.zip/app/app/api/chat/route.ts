
import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { db } from "@/lib/db"

export const dynamic = "force-dynamic"

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { messages, context } = body

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json({ error: "Invalid messages format" }, { status: 400 })
    }

    // Create system message with context
    const systemMessage = {
      role: "system",
      content: `You are a helpful AI language tutor specializing in Hungarian, German, and English. 
      
Current context:
- User level: ${context?.userLevel || 'A1'}
- Language pair: ${context?.languagePair || 'en-de'}
- Current lesson: ${context?.currentLesson || 'None'}

Guidelines:
- Be encouraging and supportive
- Provide clear, concise explanations
- Use examples to illustrate grammar points
- Adapt your language to the user's level
- When explaining mistakes, be gentle but clear
- If asked about vocabulary, provide pronunciation help
- Offer practice suggestions when appropriate
- Keep responses conversational and friendly

Available conversation modes you can suggest:
1. Free Chat - Open conversation practice
2. Roleplay - Specific scenarios (restaurant, travel, etc.)
3. Grammar Help - Explain rules and corrections
4. Vocabulary Practice - Word associations and usage
5. Exam Preparation - Focus on test strategies

Always end with a helpful follow-up question or suggestion to keep the conversation flowing.`
    }

    const allMessages = [systemMessage, ...messages]

    // Call the LLM API
    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4.1-mini',
        messages: allMessages,
        stream: true,
        max_tokens: 1000,
        temperature: 0.7,
      }),
    })

    if (!response.ok) {
      throw new Error(`LLM API error: ${response.status}`)
    }

    // Create streaming response
    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader()
        if (!reader) {
          controller.error(new Error('No response body'))
          return
        }

        const decoder = new TextDecoder()
        const encoder = new TextEncoder()

        try {
          while (true) {
            const { done, value } = await reader.read()
            if (done) break

            const chunk = decoder.decode(value, { stream: true })
            const lines = chunk.split('\n')
            
            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6)
                if (data === '[DONE]') {
                  continue
                }
                
                try {
                  const parsed = JSON.parse(data)
                  const content = parsed.choices?.[0]?.delta?.content || ''
                  if (content) {
                    controller.enqueue(encoder.encode(content))
                  }
                } catch (e) {
                  // Skip invalid JSON
                  continue
                }
              }
            }
          }
        } catch (error) {
          console.error('Stream error:', error)
          controller.error(error)
        } finally {
          controller.close()
        }
      },
    })

    // Save chat message to database (in background)
    const sessionId = `${session.user.id}_${Date.now()}`
    
    // Save user message
    if (messages.length > 0) {
      const lastMessage = messages[messages.length - 1]
      if (lastMessage.role === 'user') {
        db.chatMessage.create({
          data: {
            userId: session.user.id,
            sessionId,
            role: 'user',
            content: lastMessage.content,
            context: context || {}
          }
        }).catch(console.error) // Don't await, just log errors
      }
    }

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    })

  } catch (error) {
    console.error('Chat API error:', error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
