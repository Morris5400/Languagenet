
import ContactPage from '@/components/pages/contact-page'

export default function Contact() {
  return <ContactPage />
}
