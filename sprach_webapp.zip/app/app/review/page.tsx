
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import ReviewPage from '@/components/pages/review-page'

export default async function Review() {
  const session = await getServerSession(authOptions)
  
  // Allow access for both authenticated users and guests
  return <ReviewPage />
}
